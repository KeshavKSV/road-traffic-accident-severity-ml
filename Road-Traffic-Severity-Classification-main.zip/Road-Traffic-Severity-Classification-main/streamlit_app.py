import streamlit as st
from predict_page import show_predict_page
#from predict_page import explainable_AI
show_predict_page()
#explainable_AI()